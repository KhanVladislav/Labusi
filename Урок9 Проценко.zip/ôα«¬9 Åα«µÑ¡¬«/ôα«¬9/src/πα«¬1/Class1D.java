public interface Class1D extends Paint{
	
}